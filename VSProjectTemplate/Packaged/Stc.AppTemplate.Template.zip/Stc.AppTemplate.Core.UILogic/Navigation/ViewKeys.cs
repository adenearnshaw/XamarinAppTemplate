﻿
namespace $safeprojectname$.Navigation
{
    public class ViewKeys
    {
        public static string Main => ViewKey.MainPage.ToString();

        enum ViewKey
        {
            MainPage
        }
    }
}