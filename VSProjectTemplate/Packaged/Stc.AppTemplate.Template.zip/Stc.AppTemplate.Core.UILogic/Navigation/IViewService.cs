﻿namespace $safeprojectname$.Navigation
{
    public interface IViewService
    {
        void ReturnToMain();
        void ShowMain();
    }
}