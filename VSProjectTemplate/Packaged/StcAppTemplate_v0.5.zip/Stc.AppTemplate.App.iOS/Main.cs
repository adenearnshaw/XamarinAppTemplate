﻿using UIKit;

namespace $safeprojectname$
{
    public class Application
    {
        static void Main(string[] args)
        {
            App.Init();
            UIApplication.Main(args, null, "AppDelegate");
        }
    }
}