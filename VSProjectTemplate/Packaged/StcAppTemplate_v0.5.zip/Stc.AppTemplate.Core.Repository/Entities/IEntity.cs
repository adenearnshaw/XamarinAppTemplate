﻿namespace $safeprojectname$.Entities
{
    public interface IEntity
    {
        int ID { get; set; } 
    }
}