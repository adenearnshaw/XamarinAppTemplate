﻿namespace $safeprojectname$.Views
{
    public sealed partial class MainPage : BasePage
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
