﻿using Newtonsoft.Json;

namespace $safeprojectname$
{
    public class SampleContract
    {
        [JsonProperty]
        public string Name { get; set; }
    }
}
